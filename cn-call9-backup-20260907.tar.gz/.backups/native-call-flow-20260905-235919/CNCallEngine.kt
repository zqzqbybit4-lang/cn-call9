package com.example.mobile

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.ContextCompat
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * CN CALL native call-engine boundary.
 *
 * PHASE 1.7: [CNCallEngineImpl] is now a REAL orchestration implementation of
 * [Delegate] built on the three native components:
 *   - NativeWebSocketClient → signaling transport (owns reconnect itself)
 *   - NativeCallTokenHelper  → credentials + LiveKit token (owns HTTP)
 *   - NativeLiveKit          → media transport (owns room lifecycle)
 *
 * Activation is OPT-IN. Nothing connects automatically:
 *   - None of the connect/priming work starts from initialize() (no auto
 *     WebSocket, no auto LiveKit).
 *   - Signaling is only ever written, and LiveKit only ever joined, when a
 *     call-operation is explicitly invoked (startOutgoing/answer/...).
 *   - The FACADE (outer object) is the activation gate for the current phase:
 *     it is real and ready but keeps the old call path (Telecom + Flutter +
 *     FCM) completely untouched — wiring the facade to the live flow is the
 *     next phase.
 *
 * Protocol provenance (never invented here):
 *   - Sending side mirrors mobile/lib/services/rtc_call_manager.dart.
 *   - Receiving/routing rules and terminal states mirror server/main.py
 *     (/ws/{user_id}, message dispatch, active_calls state machine).
 *   Field names used verbatim: call_id, target_id, from_id, caller_name,
 *   reason, ring_expires_at.
 *
 * Frame inventory used by this engine (all verified against the Dart client):
 *   - "call"          (startOutgoing)      caller → server   (rtc_call_manager.dart:425)
 *   - "call_accept"   (answer)             target → server   (:486)
 *   - "call_reject"   (reject)             target → server   (:546)
 *   - "call_cancelled"(disconnect, caller while ringing)      (:556)
 *   - "hangup"        (disconnect)         either side       (:556, :598)
 *   - received: call / call_started / call_accept / call_reject /
 *     call_cancelled / hangup / timeout / signaling_rejected / session_invalid
 *
 * Ownership split (architecture report):
 *   - CNCallEngine → orchestrates signaling + media transport only.
 *   - CNCallConnection → Telecom lifecycle only (state transitions + audio).
 *   - Audio focus/routing/microphone lifecycle → owned by Android Telecom.
 *   The engine never acquires audio focus, never sets MODE_IN_COMMUNICATION,
 *   never routes the speaker for call audio, and never manages the
 *   microphone lifecycle beyond the LiveKit track on/off switch.
 */
object CNCallEngine {

    /**
     * Engine runtime state. Phase 1.7: the engine becomes real and reports
     * COMPONENTS_READY after initialize(), but the facade remains dormant so
     * the current Flutter/Telecom call path is untouched.
     */
    enum class State {
        UNINITIALIZED,
        INITIALIZED,
        COMPONENTS_READY,
        IN_CALL,
        TERMINATED,
    }

    /**
     * Callbacks surfaced up to the Telecom layer (CNCallConnection).
     * These are the single channel that translates media/signaling progress
     * into Connection state.
     */
    interface Callbacks {
        fun onMediaReady()
        fun onDisconnected()
        fun onError(message: String)
    }

    /**
     * The native signaling + media operations implemented by [CNCallEngineImpl].
     */
    interface Delegate {
        fun initialize(context: Context, callbacks: Callbacks): Boolean
        fun startIncoming(callId: String, callerId: String, callerName: String): Boolean
        fun startOutgoing(callId: String, address: String): Boolean
        fun answer(callId: String): Boolean
        fun reject(callId: String): Boolean
        fun disconnect(callId: String): Boolean
        fun hold(callId: String): Boolean
        fun unhold(callId: String): Boolean
        fun setMute(callId: String, muted: Boolean): Boolean
        fun setSpeaker(callId: String, speaker: Boolean): Boolean
        fun release(callId: String): Boolean
    }

    /**
     * REAL native engine implementation (Phase 1.7), replacing the Phase 1.6
     * placeholder. Behaviour contract mirrors the Dart call path exactly:
     *
     *   - initialize()  primes components only; connects nothing.
     *   - startIncoming() records the call; sends no frame (the invite already
     *     reached us via signaling/FCM — nothing extra is in the protocol).
     *   - startOutgoing() records callId/target and sends the "call" frame.
     *   - answer() validates the current call, sends "call_accept", then AFTER
     *     that signalling step connects LiveKit asynchronously. send() alone is
     *     NOT treated as accepted/connected; media readiness is delivered only
     *     by NativeLiveKit state + the engine listener (onMediaReady).
     *   - reject() sends "call_reject"; LiveKit is torn down only if a media
     *     room is actually present.
     *   - disconnect() sends the correct terminal frame ("call_cancelled" when
     *     a still-ringing caller cancels, otherwise "hangup") and then tears
     *     down the LiveKit room. NativeLiveKit.disconnect() alone NEVER
     *     produces a signaling hangup.
     *   - setMute/setSpeaker forward to NativeLiveKit only (no AudioManager,
     *     no signalling — the protocol has no mute frame).
     *   - hold()/unhold() return false: server/main.py has no hold/unhold
     *     message type (nothing is invented here).
     *   - release() frees the call record only; it never closes the WebSocket
     *     session and sends no frame.
     *
     * Staleness: every asynchronous edge (LiveKit listener events, the async
     * token fetch + connect) re-validates the engine [generation] AND
     * [scoredCallId] captured at the time the operation was launched, before
     * touching state or calling back. Combined with the internal generation
     * guards of NativeWebSocketClient and NativeLiveKit, a stale callback
     * from an older call can never mutate a newer one.
     */
    class CNCallEngineImpl : Delegate {

        // ------------------------------------------------------------
        // Engine state
        // ------------------------------------------------------------

        private val lock = Any()

        @Volatile
        private var callbacks: Callbacks? = null

        @Volatile
        private var appContext: Context? = null

        /** Engine epoch — bumped on every score/clear/end of a call. */
        @Volatile
        private var generation = 0L

        /** The call the engine is currently orchestrating. */
        @Volatile
        private var scoredCallId: String? = null

        /** Most recent incoming-call signal, recorded but not surfaced. */
        @Volatile
        private var pendingIncomingCall: PendingIncomingCall? = null

        /** True once this call has been accepted (answer or received call_accept). */
        @Volatile
        private var acceptedCallId: String? = null

        /** True when this endpoint started the call. */
        @Volatile
        private var isCaller = false

        /** Outgoing target user id (startOutgoing). */
        @Volatile
        private var outgoingTargetId: String? = null

        /** False after {"type":"session_invalid"}: signaling disabled. */
        @Volatile
        private var sessionTokenValid = true

        /** Last WebSocket transport error, for diagnostics only. */
        @Volatile
        private var lastSignalingError: Throwable? = null

        @Volatile
        private var wsListenerRegistered = false

        @Volatile
        private var liveKitListenerRegistered = false

        private data class PendingIncomingCall(
            val callId: String,
            val callerId: String,
            val callerName: String,
        )

        /** Background worker for blocking LiveKit-token fetches. */
        private val worker: ExecutorService by lazy {
            Executors.newSingleThreadExecutor { runnable ->
                Thread(runnable, "cn-call-engine").apply { isDaemon = true }
            }
        }

        // ------------------------------------------------------------
        // Component bridges
        // ------------------------------------------------------------

        private val webSocketListener = object : NativeWebSocketListener {
            override fun onFrame(type: String, payload: Map<String, String>) {
                handleSignalingFrame(type, payload)
            }

            override fun onClosed(code: Int, reason: String) {
                // Transport-only: NativeWebSocketClient owns reconnect, socket
                // closure is NOT call termination.
            }

            override fun onError(t: Throwable) {
                lastSignalingError = t
            }
        }

        private val liveKitListener = object : NativeLiveKitListener {
            override fun onConnected() {
                val current: String? = synchronized(lock) { scoredCallId }
                if (current == null) return
                // Media ready ONLY for the current call (NativeLiveKit itself
                // only emits for its current generation). The microphone is
                // intentionally NOT auto-enabled here: Phase 1.7 keeps the
                // mic off until explicitly enabled. Enabling it on media
                // connect is deferred to the next phase.
                callbacks?.onMediaReady()
            }

            override fun onDisconnected() {
                // A LiveKit room drop is NOT a hangup: never auto-send hangup
                // and never notify onDisconnected from media alone. Call-end
                // decisions belong to signaling; this is recorded as media
                // state only (nothing else is needed in this phase).
            }

            override fun onError(t: Throwable) {
                val current: String? = synchronized(lock) { scoredCallId }
                if (current == null) return
                // Surface the media error only when a call is actually scored;
                // combined with NativeLiveKit's own generation guard a stale
                // room error cannot target an unrelated call.
                callbacks?.onError("LiveKit media error: ${t.message}")
            }
        }

        // ------------------------------------------------------------
        // Delegate implementation
        // ------------------------------------------------------------

        override fun initialize(context: Context, callbacks: Callbacks): Boolean {
            this.appContext = context.applicationContext
            this.callbacks = callbacks
            NativeLiveKit.initialize(context.applicationContext)
            registerWebSocketListenerOnce()
            registerLiveKitListenerOnce()
            return true
        }

        override fun startIncoming(
            callId: String,
            callerId: String,
            callerName: String,
        ): Boolean {
            if (callId.isBlank() || callerId.isBlank()) return false
            synchronized(lock) {
                if (callId == scoredCallId) return true
                ++generation
                scoredCallId = callId
                isCaller = false
                outgoingTargetId = null
                acceptedCallId = null
                pendingIncomingCall =
                    PendingIncomingCall(callId, callerId, callerName)
            }
            return true
        }

        override fun startOutgoing(callId: String, address: String): Boolean {
            if (callId.isBlank() || address.isBlank()) return false
            val targetId = parseTargetId(address)
            if (targetId.isBlank()) return false

            synchronized(lock) {
                if (callId == scoredCallId && isCaller) return true
                ++generation
                scoredCallId = callId
                isCaller = true
                outgoingTargetId = targetId
                pendingIncomingCall = null
                acceptedCallId = null
            }

            if (!ensureSignalingConnected()) return false

            val userId = NativeCallTokenHelper.restoreUserId(
                appContext ?: return false,
            ) ?: return false

            // Verified: rtc_call_manager.dart startCall() (lines 425-431).
            // caller_name is omitted here because NativeCallTokenHelper does
            // not expose the display name; server/main.py (line 1044) falls
            // back to its default "مستخدم CN CALL" when absent.
            val sent = NativeWebSocketClient.send(
                "call",
                mapOf(
                    "call_id" to callId,
                    "target_id" to targetId,
                    "from_id" to userId,
                ),
            )
            return sent
        }

        override fun answer(callId: String): Boolean {
            val current: Boolean
            val targetId: String?
            synchronized(lock) {
                current = callId == scoredCallId
                targetId = if (isCaller) outgoingTargetId else pendingIncomingCall?.callerId
            }
            if (!current) return false
            if (targetId.isNullOrBlank()) return false
            if (!ensureSignalingConnected()) return false

            // Verified: rtc_call_manager.dart _acceptCall() (lines 486-490) and
            // server/main.py "call_accept" (line 1139): target, status ringing.
            val sent = NativeWebSocketClient.send(
                "call_accept",
                mapOf("call_id" to callId, "target_id" to targetId),
            )
            synchronized(lock) {
                if (callId == scoredCallId) acceptedCallId = callId
            }

            if (sent) {
                // Only the signalling step is done. This is NOT accepted/
                // connected yet: media-ready is delivered later exclusively by
                // NativeLiveKit state + the engine LiveKit listener
                // (callbacks.onMediaReady).
                startLiveKitConnect(callId)
            }
            return sent
        }

        override fun reject(callId: String): Boolean {
            val current: Boolean
            val targetId: String?
            synchronized(lock) {
                current = callId == scoredCallId
                targetId = if (isCaller) outgoingTargetId else pendingIncomingCall?.callerId
            }
            if (!current) return false
            if (targetId.isNullOrBlank()) return false
            if (!ensureSignalingConnected()) return false

            // Verified: rtc_call_manager.dart rejectCall() → _cleanupCall()
            // signalType call_reject (lines 543-548) and server/main.py
            // "call_reject" (line 1142): target, status ringing.
            val sent = NativeWebSocketClient.send(
                "call_reject",
                mapOf("call_id" to callId, "target_id" to targetId),
            )

            // Only tear down the media room if one actually exists.
            if (NativeLiveKit.state != NewNativeLiveKitState.IDLE) {
                NativeLiveKit.disconnect()
            }

            synchronized(lock) {
                if (callId == scoredCallId) {
                    ++generation
                    scoredCallId = null
                    pendingIncomingCall = null
                    acceptedCallId = null
                }
            }
            return sent
        }

        override fun disconnect(callId: String): Boolean {
            val current: Boolean
            val targetId: String?
            val callerStillRinging: Boolean
            synchronized(lock) {
                current = callId == scoredCallId
                targetId = if (isCaller) outgoingTargetId else pendingIncomingCall?.callerId
                callerStillRinging = isCaller && acceptedCallId != callId
            }
            if (!current) return false
            if (targetId.isNullOrBlank()) return false

            // Verified: rtc_call_manager.dart hangup() (lines 551-559) —
            // caller cancels while still ringing → "call_cancelled",
            // otherwise → "hangup". Both are terminal in server/main.py
            // (lines 1146, 1150).
            ensureSignalingConnected()
            NativeWebSocketClient.send(
                if (callerStillRinging) "call_cancelled" else "hangup",
                mapOf("call_id" to callId, "target_id" to targetId),
            )

            // Media leg end (NativeLiveKit.disconnect is media-only and can
            // never produce a signaling hangup by itself).
            if (NativeLiveKit.state != NewNativeLiveKitState.IDLE) {
                NativeLiveKit.disconnect()
            }

            synchronized(lock) {
                if (callId == scoredCallId) {
                    ++generation
                    scoredCallId = null
                    pendingIncomingCall = null
                    acceptedCallId = null
                    isCaller = false
                    outgoingTargetId = null
                }
            }
            return true
        }

        override fun hold(callId: String): Boolean = false

        override fun unhold(callId: String): Boolean = false

        override fun setMute(callId: String, muted: Boolean): Boolean {
            if (!isScored(callId)) return false
            // LiveKit track on/off only. No AudioManager and no signaling
            // mute frame (the protocol has no "mute" message type).
            NativeLiveKit.setMicrophoneEnabled(!muted)
            return true
        }

        override fun setSpeaker(callId: String, speaker: Boolean): Boolean {
            if (!isScored(callId)) return false
            // NativeLiveKit.setSpeaker is a documented no-op since Phase 1.5-D
            // (the LiveKit routing API is audioswitch and competes with
            // Telecom). No AudioManager/AudioSwitch routing here.
            NativeLiveKit.setSpeaker(speaker)
            return true
        }

        override fun release(callId: String): Boolean {
            val released: Boolean
            synchronized(lock) {
                released = callId == scoredCallId
                if (released) {
                    ++generation
                    scoredCallId = null
                    pendingIncomingCall = null
                    acceptedCallId = null
                    isCaller = false
                    outgoingTargetId = null
                }
            }
            // Frees call resources only: the WebSocket session is session-
            // scoped and stays connected (no close), and no frame is sent
            // automatically.
            return released
        }

        // ------------------------------------------------------------
        // Public lifecycle helpers (also used by the facade hooks)
        // ------------------------------------------------------------

        fun onCallStarted(callId: String) {
            synchronized(lock) {
                ++generation
                scoredCallId = callId
            }
        }

        fun onCallConnected(callId: String) {
            synchronized(lock) {
                if (callId != scoredCallId) return
                // Reserved: enabling the local microphone
                // (NativeLiveKit.setMicrophoneEnabled(true)) belongs here once
                // the engine drives media; Phase 1.7 leaves the mic off.
            }
        }

        fun onCallEnded(reason: String) {
            // Media-only teardown. Never sends hangup: a real signaling
            // hangup travels exclusively through the WebSocket layer
            // (disconnect() with the terminal frame).
            NativeLiveKit.disconnect()
            synchronized(lock) {
                ++generation
                scoredCallId = null
                pendingIncomingCall = null
                acceptedCallId = null
                isCaller = false
                outgoingTargetId = null
            }
        }

        // ------------------------------------------------------------
        // Internal orchestration
        // ------------------------------------------------------------

        private fun isScored(callId: String): Boolean {
            synchronized(lock) {
                return callId == scoredCallId
            }
        }

        /**
         * Restores session credentials once (NativeCallTokenHelper) and opens/
         * reuses the authenticated WebSocket. Called only from explicit
         * call-operations; NEVER from initialize().
         */
        private fun ensureSignalingConnected(): Boolean {
            val context = appContext ?: return false
            val userId = NativeCallTokenHelper.restoreUserId(context) ?: return false
            val token = NativeCallTokenHelper.restoreAccessToken(context) ?: return false
            if (userId.isBlank() || token.isBlank()) return false
            return NativeWebSocketClient.connect(userId.trim(), token.trim())
        }

        /**
         * Starts the async LiveKit join: fetch the token on the background
         * worker, re-validate generation + current call AFTER the (slow) fetch,
         * and only then hand it to NativeLiveKit.connect. The final
         * media-ready signal comes from [liveKitListener].
         */
        private fun startLiveKitConnect(callId: String) {
            val myGeneration: Long
            val context: Context
            synchronized(lock) {
                if (callId != scoredCallId) return
                myGeneration = generation
            }
            context = appContext ?: return
            val userId = NativeCallTokenHelper.restoreUserId(context) ?: return

            worker.execute {
                val result = NativeCallTokenHelper.fetchLiveKitToken(
                    context,
                    userId,
                    callId,
                )
                val stillCurrent: Boolean
                synchronized(lock) {
                    stillCurrent =
                        myGeneration == generation && callId == scoredCallId
                }
                if (!stillCurrent) return@execute
                if (result == null) {
                    callbacks?.onError("LiveKit token fetch failed call_id=$callId")
                    return@execute
                }
                NativeLiveKit.connect(result.url, result.token, callId)
            }
        }

        private fun registerWebSocketListenerOnce() {
            synchronized(lock) {
                if (!wsListenerRegistered) {
                    NativeWebSocketClient.addListener(webSocketListener)
                    wsListenerRegistered = true
                }
            }
        }

        private fun registerLiveKitListenerOnce() {
            synchronized(lock) {
                if (!liveKitListenerRegistered) {
                    NativeLiveKit.setListener(liveKitListener)
                    liveKitListenerRegistered = true
                }
            }
        }

        /**
         * Translates an incoming signaling frame into internal engine state
         * only — no Telecom action, no Flutter UI and no automatic LiveKit
         * connect in Phase 1.7. Frames about a call that is not the current
         * one are ignored as stale.
         */
        private fun handleSignalingFrame(type: String, payload: Map<String, String>) {
            val frameCallId = payload["call_id"].orEmpty()
            when (type) {
                "call" -> {
                    // Incoming invitation, forwarded to the target by the
                    // server (main.py lines 1079-1084). Recorded only.
                    val callerId = (payload["from_id"] ?: payload["caller_id"]).orEmpty()
                    val callerName = (payload["caller_name"] ?: callerId).orEmpty()
                    synchronized(lock) {
                        ++generation
                        pendingIncomingCall =
                            PendingIncomingCall(frameCallId, callerId, callerName)
                    }
                    println(
                        "[CN CALL][ENGINE] signaling call call_id=$frameCallId" +
                            " caller_id=$callerId",
                    )
                }

                "call_started" -> {
                    // Caller-side ack that the server accepted the call
                    // (main.py line 1069). No state change needed here.
                    println("[CN CALL][ENGINE] signaling call_started call_id=$frameCallId")
                }

                "call_accept" -> {
                    synchronized(lock) {
                        val matches =
                            frameCallId.isNotEmpty() &&
                                (frameCallId == scoredCallId ||
                                    frameCallId == pendingIncomingCall?.callId)
                        if (matches) {
                            acceptedCallId = frameCallId
                            println(
                                "[CN CALL][ENGINE] signaling call_accept call_id=$frameCallId",
                            )
                        } else {
                            println(
                                "[CN CALL][ENGINE] signaling call_accept stale call_id=$frameCallId",
                            )
                        }
                    }
                }

                "call_reject", "call_cancelled", "hangup", "timeout", "signaling_rejected" ->
                    clearScoredCall(frameCallId, type)

                "session_invalid" -> {
                    sessionTokenValid = false
                    println("[CN CALL][ENGINE] signaling session_invalid (reconnect disabled)")
                }

                else -> {
                    // Ignored frames stay transport-level, as in the Dart client.
                }
            }
        }

        /**
         * Clears engine call state when a terminal signaling frame arrives.
         * Mutates only when the frame references the current epoch's call;
         * late frames from older calls are ignored.
         */
        private fun clearScoredCall(callId: String, event: String) {
            val cleared: Boolean
            synchronized(lock) {
                val matchesScored = callId == scoredCallId
                val matchesPending =
                    callId.isNotEmpty() && callId == pendingIncomingCall?.callId
                cleared = matchesScored || matchesPending
                if (cleared) {
                    ++generation
                    scoredCallId = null
                    pendingIncomingCall = null
                    acceptedCallId = null
                    isCaller = false
                    outgoingTargetId = null
                }
            }
            println(
                "[CN CALL][ENGINE] signaling $event call_id=$callId cleared=$cleared",
            )
        }

        /** Extracts the target user id from an address like "cncall:<id>". */
        private fun parseTargetId(address: String): String {
            val trimmed = address.trim()
            if (trimmed.isEmpty()) return ""
            val uri = Uri.parse(trimmed)
            return if (uri.scheme.equals("cncall", ignoreCase = true)) {
                uri.schemeSpecificPart.orEmpty()
            } else {
                trimmed
            }
        }
    }

    /** Real delegate. Phase 1.7: a fully functional native engine. */
    private var delegate: Delegate? = null

    /** Engine lifecycle state. */
    @Volatile
    var state: State = State.UNINITIALIZED
        private set

    @Volatile
    private var callbacks: Callbacks? = null

    /**
     * Install the native engine and record the working Context. The
     * permission check is the unchanged existing policy; prime the three
     * components (fully handled inside [CNCallEngineImpl.initialize]);
     * nothing connects automatically. Returns true once COMPONENTS_READY —
     * the engine is real but NOT yet wired into the live call flow (that is
     * the next phase), so current Telecom/Flutter behavior is untouched.
     */
    fun initialize(context: Context, callbacks: Callbacks): Boolean {
        if (!hasRecordAudioPermission(context)) {
            return unavailable(
                "initialize",
                "",
                callbacks,
                "RECORD_AUDIO permission is not granted",
            )
        }
        this.callbacks = callbacks
        if (delegate == null) {
            delegate = CNCallEngineImpl()
        }
        if (state == State.UNINITIALIZED) {
            state = State.INITIALIZED
        } else if (state == State.TERMINATED) {
            // Re-usable after a full teardown.
            state = State.INITIALIZED
        }
        val ready = delegate?.initialize(context, callbacks) == true
        if (ready) {
            state = State.COMPONENTS_READY
        }
        return ready
    }

    fun hasRecordAudioPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO,
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun isReady(): Boolean = state == State.COMPONENTS_READY && delegate != null

    // ------------------------------------------------------------
    // Activation gate (Phase 1.7)
    //
    // These facade methods are the opt-in switch of the native flow. The real
    // implementation lives in [CNCallEngineImpl] and is fully able to run the
    // verified signaling/media protocol, but this phase must NOT take the live
    // session over yet: the Flutter path keeps driving calls, and wiring the
    // facade through to the engine (FCM → Telecom → engine) is the next
    // phase. Hence each returns false here — identical to today's behavior.
    // ------------------------------------------------------------

    fun startIncoming(
        callId: String,
        callerId: String,
        callerName: String,
    ): Boolean {
        val currentDelegate = delegate
            ?: return unavailable("startIncoming", callId, callbacks)

        if (state == State.UNINITIALIZED || state == State.TERMINATED) {
            return unavailable("startIncoming", callId, callbacks, "Native call engine is not initialized")
        }

        return currentDelegate.startIncoming(callId, callerId, callerName)
    }

    fun startOutgoing(callId: String, address: String): Boolean {
        val currentDelegate = delegate
            ?: return unavailable("startOutgoing", callId, callbacks)

        if (state == State.UNINITIALIZED || state == State.TERMINATED) {
            return unavailable("startOutgoing", callId, callbacks, "Native call engine is not initialized")
        }

        return currentDelegate.startOutgoing(callId, address)
    }

    fun answer(callId: String): Boolean {
        val currentDelegate = delegate
            ?: return unavailable("answer", callId, callbacks)

        if (state == State.UNINITIALIZED || state == State.TERMINATED) {
            return unavailable("answer", callId, callbacks, "Native call engine is not initialized")
        }

        return currentDelegate.answer(callId)
    }

    fun reject(callId: String): Boolean {
        val currentDelegate = delegate
            ?: return unavailable("reject", callId, callbacks)

        if (state == State.UNINITIALIZED || state == State.TERMINATED) {
            return unavailable("reject", callId, callbacks, "Native call engine is not initialized")
        }

        return currentDelegate.reject(callId)
    }

    fun disconnect(callId: String): Boolean {
        val currentDelegate = delegate
            ?: return unavailable("disconnect", callId, callbacks)

        if (state == State.UNINITIALIZED || state == State.TERMINATED) {
            return unavailable("disconnect", callId, callbacks, "Native call engine is not initialized")
        }

        return currentDelegate.disconnect(callId)
    }

    fun setMute(callId: String, muted: Boolean): Boolean {
        val currentDelegate = delegate
            ?: return unavailable("setMute", callId, callbacks)

        if (state == State.UNINITIALIZED || state == State.TERMINATED) {
            return unavailable("setMute", callId, callbacks, "Native call engine is not initialized")
        }

        return currentDelegate.setMute(callId, muted)
    }

    fun setSpeaker(callId: String, speaker: Boolean): Boolean {
        val currentDelegate = delegate
            ?: return unavailable("setSpeaker", callId, callbacks)

        if (state == State.UNINITIALIZED || state == State.TERMINATED) {
            return unavailable("setSpeaker", callId, callbacks, "Native call engine is not initialized")
        }

        return currentDelegate.setSpeaker(callId, speaker)
    }

    fun hold(callId: String): Boolean {
        val currentDelegate = delegate
            ?: return unavailable("hold", callId, callbacks)

        if (state == State.UNINITIALIZED || state == State.TERMINATED) {
            return unavailable("hold", callId, callbacks, "Native call engine is not initialized")
        }

        return currentDelegate.hold(callId)
    }

    fun unhold(callId: String): Boolean {
        val currentDelegate = delegate
            ?: return unavailable("unhold", callId, callbacks)

        if (state == State.UNINITIALIZED || state == State.TERMINATED) {
            return unavailable("unhold", callId, callbacks, "Native call engine is not initialized")
        }

        return currentDelegate.unhold(callId)
    }

    fun release(callId: String): Boolean {
        val currentDelegate = delegate
            ?: return unavailable("release", callId, callbacks)

        return currentDelegate.release(callId)
    }

    // ------------------------------------------------------------
    // Lifecycle hooks (routed into the real engine)
    // ------------------------------------------------------------

    /**
     * Scores a new call into the engine (fresh epoch). Does NOT start media or
     * signal by itself.
     */
    fun onCallStarted(callId: String) {
        (delegate as? CNCallEngineImpl)?.onCallStarted(callId)
        if (state == State.INITIALIZED || state == State.COMPONENTS_READY) {
            state = State.IN_CALL
        }
    }

    /**
     * Marks the scored call as media-connected; the place where the local
     * microphone will be enabled (NativeLiveKit.setMicrophoneEnabled(true))
     * once the engine drives media. Phase 1.7 leaves the mic off.
     */
    fun onCallConnected(callId: String) {
        (delegate as? CNCallEngineImpl)?.onCallConnected(callId)
    }

    /**
     * Tears down the engine's media transport only. NativeLiveKit.disconnect()
     * leaves + releases the room and never sends a signaling hangup; a real
     * hangup comes exclusively from the WebSocket layer.
     */
    fun onCallEnded(reason: String) {
        (delegate as? CNCallEngineImpl)?.onCallEnded(reason)
        state = State.TERMINATED
    }

    private fun unavailable(
        operation: String,
        callId: String,
        callbacks: Callbacks? = null,
        reason: String? = null,
    ): Boolean {
        val message = reason ?: "Native call engine is not configured: $operation"
        println(
            "[CN CALL][TELECOM] $message call_id=$callId",
        )
        callbacks?.onError(message)
        return false
    }
}
